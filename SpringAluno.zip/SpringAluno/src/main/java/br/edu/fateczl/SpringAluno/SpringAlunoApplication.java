package br.edu.fateczl.SpringAluno;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAlunoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAlunoApplication.class, args);
	}

}
