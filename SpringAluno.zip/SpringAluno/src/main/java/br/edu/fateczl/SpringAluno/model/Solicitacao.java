package br.edu.fateczl.SpringAluno.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Solicitacao {
	
	Dispensa dispensa;

	@Override
	public String toString() {
		return "Solicitacao [dispensa=" + dispensa + "]";
	}
	
	

}
